import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "recommended_ind"
FEATURE_KEY = "review_text"

def transformed_name(key):
    """Helper function for renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features.
    
    Args:
        inputs: map from feature keys to raw or sparse features.
    
    Returns:
        outputs: map from feature keys to transformed features.
    """
    outputs = {}

    # Handle the Review Text feature
    # Check if the feature is a SparseTensor
    if isinstance(inputs[FEATURE_KEY], tf.sparse.SparseTensor):
        # Convert SparseTensor to DenseTensor
        review_text_dense = tf.sparse.to_dense(inputs[FEATURE_KEY], default_value='')
    else:
        review_text_dense = inputs[FEATURE_KEY]

    # Apply tf.strings.lower to the dense tensor
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(review_text_dense)

    # Handle the Recommended IND label
    if isinstance(inputs[LABEL_KEY], tf.sparse.SparseTensor):
        # Convert SparseTensor to DenseTensor for the label
        label_dense = tf.sparse.to_dense(inputs[LABEL_KEY], default_value='0')
    else:
        label_dense = inputs[LABEL_KEY]

    # Cast the label to tf.int64
    outputs[transformed_name(LABEL_KEY)] = tf.cast(label_dense, tf.int64)
    # Example encoding step (could be more complex in practice)
    encoded_text = tf.strings.to_hash_bucket(inputs[FEATURE_KEY], num_buckets=1000)
    
    # Padding (conceptually, as TensorFlow Transform doesn't directly support this)
    padded_text = tf.keras.preprocessing.sequence.pad_sequences(encoded_text, maxlen=100, padding='post', truncating='post')
    
    outputs = {
        transformed_name(FEATURE_KEY): padded_text,
        # handle other features
    }
    return outputs
